<?php
error_reporting(0);
$ip    = $_SERVER['REMOTE_ADDR'];
$getip = 'http://ip-api.com/json/' . $ip;
$curl  = curl_init();
curl_setopt($curl, CURLOPT_URL, $getip);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content = curl_exec($curl);
curl_close($curl);
$details     = json_decode($content);
$negara      = $details->countryCode;
$nama_negara = $details->country;
$kode_negara = strtolower($negara);
?>